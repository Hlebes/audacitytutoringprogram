﻿namespace QuizClassesAndSerialization
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.QuizTextLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // QuizTextLabel
            // 
            this.QuizTextLabel.AutoSize = true;
            this.QuizTextLabel.Location = new System.Drawing.Point(12, 9);
            this.QuizTextLabel.Name = "QuizTextLabel";
            this.QuizTextLabel.Size = new System.Drawing.Size(35, 13);
            this.QuizTextLabel.TabIndex = 0;
            this.QuizTextLabel.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.QuizTextLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label QuizTextLabel;
    }
}

