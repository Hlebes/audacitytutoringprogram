﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace QuizClassesAndSerialization
{
    class Quiz
    {
        [XmlAttribute]
        public int QuizId;
        public string QuizType;
        public string QuizText;
        public String[] Options;
        public String[] Answers;

        public Quiz(int QuizId, string QuizType, string QuizText, String[] Options, String[] Answers)
        {
            this.QuizId = QuizId;
            this.QuizType = QuizType;
            this.QuizText = QuizText;
            this.Options = Options;
            this.Answers = Answers;
        }

        public Quiz()
        {
            this.QuizId = 1337;
            this.QuizType = "radio";
            this.QuizText = "Текст вопроса";
            string[] opt = {"1", "2", "3"};
            string[] answ = {"1"};
            this.Options = opt;
            this.Answers = answ;
        }
    }
}
