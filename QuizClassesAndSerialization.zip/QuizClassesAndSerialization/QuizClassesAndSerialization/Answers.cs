﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizClassesAndSerialization
{
    class Answers
    {
        int QuizId;
        Array Options;
    }
}
