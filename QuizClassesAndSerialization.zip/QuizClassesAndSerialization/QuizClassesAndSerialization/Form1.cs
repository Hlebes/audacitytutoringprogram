﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace QuizClassesAndSerialization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string[] quiz1options = { "1", "2", "не знаю" };
            string[] quiz1answers = {"1"};
            Quiz quiz1 = new Quiz(1, "radio", "Сколько тут правильных ответов?", quiz1options, quiz1answers);
            SerializeObject("classobject", quiz1);
        }

        public void SerializeObject(string filename, Quiz quiz) 
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Quiz));
            TextWriter writer = new StreamWriter(filename);
            serializer.Serialize(writer, quiz);
            writer.Close();
        }
    }
}
